class PrincipalController < ApplicationController
  def index
  end

  def menu
  end
end
